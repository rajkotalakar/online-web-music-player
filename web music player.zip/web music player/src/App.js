import React, { useState } from 'react';
import './App.css';
const App = () => {
  const [songs, setSongs] = useState([
    {
      id: 1,
      title: 'Song 1',
      artist: 'Artist 1',
      url: './1.mp3',
    },
    {
      id: 2,
      title: 'Song 2',
      artist: 'Artist 2',
      url: './2.mp3',
    },
    {
      id: 3,
      title: 'Song 3',
      artist: 'Artist 3',
      url: './3.mp3',
    },
    {
      id: 4,
      title: 'Song 4',
      artist: 'Artist 4',
      url: './1.mp3',
    },
    {
      id: 5,
      title: 'Song 5',
      artist: 'Artist 5',
      url: './2.mp3',
    },
    {
      id: 6,
      title: 'Song 6',
      artist: 'Artist 6',
      url: './3.mp3',
    },
    // Add more songs as needed
  ]);

  const [currentSong, setCurrentSong] = useState(null);

  const handlePlayPause = (song) => {
    if (currentSong && currentSong.id === song.id) {
      // Pause the current song
      setCurrentSong(null);
    } else {
      // Play the selected song
      setCurrentSong(song);
    }
  };

  return (
    <div className="music-app">
      <header>
        <img
          src="./r1.jpg"
          alt="Musical Background"
          className="background-image"
        />
        <nav>
          <ul>
            <li>Home</li>
            <li>About</li>
            <li>Contact</li>
          </ul>
        </nav>
        <h1>My Music Playlist</h1>
      </header>
      <div className='about'> 

      
      <h1>
        ABOUT US
      </h1>
      <p>
      
Welcome to "My Music Playlist," a vibrant and user-friendly musical website designed with the dynamic aesthetics of Spotify in mind. The site boasts an engaging and intuitive interface, featuring a stunning musical background that sets the tone for an immersive experience. The header includes a sleek navigation menu, allowing users to seamlessly explore various sections of the site. The main content area showcases a curated collection of music cards, each representing a unique song. These cards not only display the song title and artist but also provide interactive play and pause buttons, offering users the ability to control their music experience effortlessly. The design is elegantly crafted with a red and white color palette, creating a visually appealing and cohesive atmosphere. Whether you're discovering new tunes or revisiting favorites, "My Music Playlist" offers a delightful space for music enthusiasts to enjoy a personalized and aesthetically pleasing journey.
      </p>
      </div>
      <main>
        {songs.map((song) => (
          <div key={song.id} className={`music-card ${currentSong?.id === song.id ? 'playing' : ''}`}>
            <h2>{song.title}</h2>
            <p>{song.artist}</p>
            <div className="buttons">
              <button onClick={() => handlePlayPause(song)}>
                {currentSong?.id === song.id ? 'Pause' : 'Play'}
              </button>
            </div>
          </div>
        ))}
      </main>
      <footer>
        <p>&copy; 2023 Music App</p>
      </footer>
    </div>
  );
};

export default App;